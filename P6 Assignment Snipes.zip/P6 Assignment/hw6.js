var rootStyle; 
function createCSSVariables(){
    var root = document.querySelector(":root");
    root.style.setProperty("font-size", "2vw");
    root.style.setProperty("--fivepx", "0.31rem");
    root.style.setProperty("--fiftypx", "3.125rem");

    rootStyle = getComputedStyle(root);
}

function addNodeV2(pNode, ob){
    var node=document.createElement(ob.tagName);
    for (let x in ob){
        if(x != "tagName") {
           if(x != "text")
               node.setAttribute(x, ob[x]);
           else node.innerHTML = ob[x];
        }    
    }
    pNode.appendChild(node);
    return node;
}

function createBanner(){
    //setup your ob for this banner
    var ob={
        tagName: "header",
        class  : "jumbotron text-center display-4",
       // src    : 
       // href   :
       text: "<h1>Welcome to Snipes's Webpage</h1>"
    }
    addNodeV2(document.body,    ob);
}

const L1            = [];
const L1Attrs       = [];

const L2            = [[]];
const L2Attrs       = [[]];

const L3            = [[[]]];
const L3Attrs       = [[[]]];

function createContainer1(){
    L1Attrs[0] = {
        tagName     : "div",
        class       : "container-fluid",
     //   text        : "First container",
    }

    L2Attrs[0][0] = {
        tagName     : "ul",
        class       : "nav nav-tabs",
        role        : "tablist",
    }

    L3Attrs[0][0][0] = {
        tagName     : "li",
        class       : "nav-item",
        text        :  '<a class="nav-link active" data-toggle="tab" href="#home">Home</a>'
    }

    L3Attrs.push([[]]);
    L3Attrs[0][0][1] = {
        tagName     : "li",
        class       : "nav-item",
        text        : ' <a class="nav-link" data-toggle="tab" href="#menu1">Post Graduation Plans/Strengths and Weaknesses</a>'
    }

    L3Attrs.push([[]]);
    L3Attrs[0][0][2] = {
        tagName     : "li",
        class       : "nav-item",
        text        : ' <a class="nav-link" data-toggle="tab" href="#menu2">Special Thanks</a>'
    }



    L2Attrs.push([]);

    L2Attrs[0][1]  = {
        tagName     : "div",
        class       : "tab-content",
    }

    L3Attrs.push([[]]);
    L3Attrs[0][0][4] = {
        tagName       : "div",
        class         : "container-fluid tab-pane active",
        id            : "home",
        text          :   ' <h3>Home</h3> '
                        + '<p>Greetings users! Over this past semester, you have been a witness to my pros, cons, likes, and dislikes.</p>'
                        + '<p>For this platform, I want to inform you on my plans after my college graduation from Albany State University.</p>'
                        + '<p>I want to discuss my weaknesses and strengths that helped shaped me here at Albany State University.</p>'
                        + '<p>Lastly, I going to thank the professors that helped me get to through this journey.</p>'
    }

    L3Attrs.push([[]]);
    L3Attrs[0][0][5] = {
        tagName         : "div",
        class           : "container-fluid tab-pane fade",
        id              : "menu1",
        text            : ' <h3>Post Graduation Plans/Strengths and Weaknesses</h3> '
                        + '<p>After graduation, I will still make my last contributions to ASU by participating in the Summer STEM Enrichment Program being held this summer.</p>'
                        + '<p>In this program, kids will be able to learn C++ programming language through Arduino as well as build their own game, learn about drones, and engage in STEM/STEAM activities.</p>'
                        + '<p>To be honest, I cannot really describe my strengths or weaknesses. When it comes to my work ethic, I always manage to give 110%.</p>'
                        + '<p>When it comes to learning a new skill, it would take a little longer for me to master it. I may show a little anxiety from time to time for certian activities that are in my field.</p>'
                        + '<p>I tend to show much worry when a new project comes along, feeling like I will never be able to find a solution in time or forget the material all together.</p>'
                        + '<p>I believe all of my strengths come from my family, die to their actions in both education and hard labor. I believe that I am just born with it.</p>'
    }

    L3Attrs.push([[]]);
    L3Attrs[0][0][6]   = {
        tagName         : "div", 
        class           : "container tab-pane fade",
        id              : "menu2",            
        text            : ' <h3>Special Thanks</h3> '
                         +'<p>To Dr. Hu, thank you for giving us your all when it comes to teaching. You never worry about tests or homework being due at a specific because you would rather have us learn the material for our future careers than in our curriculum.</p>'
                         +'<p>In addition, thank you for always letting us know what internships were out there for grabs.</p>'
                         +'<p>To Dr. Roosta, plenty of times alot of students have not seen you eye to eye with yourteaching methods, but if there is one thing we can all agree on, it is the fact that you made us take our coding skills alot more seriously than we have before.</p>'
                         +'<p>To Mr. Little, thank you for all that you do for your students by making each class an engagement. You are literally there for us through thick and thin when we have troubles with our assignemnts. With your teachings, we learned every twist and turn through with every program all to find a simple solutiona and we will take those teachings with us across the stage while earning our diploma.</p>'
                         +'<p>To Dr. Owor, you have given us so much knowledge pertaining to cybersecurity. I would have never thought in a million years that I would have some interest in a company like IBM. Because of you, I am familar withh Linux, I was able to contribute to ASU the best way I could in my field, and lastly, you have given many upper and lower classmen a field to have interest in.</p>'
                         +'<p>To Dr. Hatch, thank you for making Operation Research an incredible experience. I would have never had thought that companies would use tnat much arithmetic on measurements and travel on a product as small as ice cream. In addition, thank you for staying with us in study tables because it was a big help whether you believe it or not. Lastly, thank you for getting ASU students to the Battle of the Brains. It was most certainly a fun experience.</p>'
                         +'<p>Lastly, to Dr. Ofodile and Ms. Breedlove, thank you for all that you do for students of the department. You really help us put ourselves out there for entry level positions, internships, scholarships, and mentorships. You are what makes this department whole. Whenever a student is in need of service, you are always there to provide.</p>'
                         +'<h2>THANK YOU ALL!</h2>'
    }       

L1[0]       = addNodeV2(document.body, L1Attrs[0]);

L2[0][0]    =addNodeV2(L1[0], L2Attrs[0][0]);

L3[0][0][0] =addNodeV2(L2[0][0], L3Attrs[0][0][0]);

L3.push([[]]);
L3[0][0][1] =addNodeV2(L2[0][0], L3Attrs[0][0][1]);
L3.push([[]]);
L3[0][0][2] =addNodeV2(L2[0][0], L3Attrs[0][0][2]);

L2[0].push([]);  
L2[0][1]    =addNodeV2(L1[0],       L2Attrs[0][1]);
L3.push([[]]);

L3[0][0][4] =addNodeV2(L2[0][1],    L3Attrs[0][0][4]);
L3.push([[]]);
L3[0][0][5] =addNodeV2(L2[0][1],    L3Attrs[0][0][5]);
L3.push([[]]);
L3[0][0][6] =addNodeV2(L2[0][1],    L3Attrs[0][0][6]);

}

$(document).ready(
    function (){
        createBanner();

        createContainer1();
         
        
    }
);